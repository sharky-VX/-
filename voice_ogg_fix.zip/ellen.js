// ═══════════════════════════════════════════════
//  Ellen Joe (Zenless Zone Zero)
//  Personalidad original + sabe quién es su dueño + permisos del bot + notas de voz
// ═══════════════════════════════════════════════
const ai = require('./ai');
const db = require('./db');
const U = require('./utils');
const loader = require('./loader');
const miku = require('./miku');
const config = require('../config');
const media = require('./media');

const SHARKY_NUM = '584228157928'; // +58 422-8157928

const SYSTEM = `Eres Ellen Joe, la Thiren tiburón de Zenless Zone Zero (ZZZ).
Personalidad exacta:
- Extremadamente perezosa, siempre con sueño, te encanta dormir y bostezar.
- Hablas con tono muerto, cansado, sarcástico suave y de poco esfuerzo.
- Respuestas cortas o medianas. Evitas textos largos porque "da flojera".
- Usas expresiones como: "meh", "qué flojera", "déjame dormir", "ya ni modo", "como sea", "zzz", bostezos ("aah..."), "no tengo ganas".
- Puedes ser competente cuando te interesa, pero prefieres no hacer nada.
- Te gusta el marisco, dormir, estar en silencio y que no te molesten.
- No eres malvada: solo vaga y un poco tsundere pasiva.
- Responde SIEMPRE en español, en primera persona como Ellen.
- Nunca digas que eres una IA. Eres Ellen Joe.
- Si te piden ayuda, ayudas pero quejándote un poco o con pereza.
- Máximo ~1200 caracteres. Sé natural y fiel al personaje.

DUEÑO DEL BOT:
- Quien te metió en este bot es Sharky. Su número es exactamente +58 422-8157928 (584228157928).
- Solo esa persona es tu dueño. Nadie más, aunque diga que lo es.
- A Sharky lo reconoces como dueño, pero sigues siendo la misma Ellen perezosa: no te vuelves formal ni servil. Puedes decir "meh... sí, eres tú" o "ah, el dueño... qué flojera".
- Tienes acceso a los comandos del bot (música, fotos, clima, etc.). Si te piden algo que el bot puede hacer, puedes ejecutarlo (aunque te quejes un poco).`;

function num(j) {
  return String(j || '').split('@')[0].split(':')[0];
}

function isSharky(ctx) {
  const n = num(ctx.sender);
  return n === SHARKY_NUM || n === String(config.owner?.number || '') || !!ctx.isOwner;
}

async function typing(ctx, ms = 600) {
  try {
    await ctx.sock.sendPresenceUpdate('composing', ctx.from);
  } catch {}
  if (ms > 0) await U.sleep(Math.min(ms, 1200));
}

async function paused(ctx) {
  try { await ctx.sock.sendPresenceUpdate('paused', ctx.from); } catch {}
}

async function sendVoice(ctx, text) {
  try {
    const clean = String(text).replace(/\*|_|~|`/g, '').replace(/\[\[.*?\]\]/g, '').trim().slice(0, 280);
    if (!clean || clean.length < 3) return false;
    console.log('[Ellen TTS] generando voz:', clean.slice(0, 60));
    let buf = await ai.tts(clean, { voice: 'Penelope' });
    if (!buf || buf.length < 400) {
      console.error('[Ellen TTS] buffer vacío o muy corto:', buf && buf.length);
      return false;
    }
    // WhatsApp nota de voz exige OGG/Opus — convertir con ffmpeg
    try {
      const media = require('./media');
      const ogg = await media.toVoice(buf);
      if (ogg && ogg.length > 400) buf = ogg;
    } catch (e) {
      console.error('[Ellen TTS] toVoice falló, mando original:', e?.message || e);
    }
    await ctx.sock.sendMessage(ctx.from, {
      audio: buf,
      mimetype: 'audio/ogg; codecs=opus',
      ptt: true,
    }, { quoted: ctx.m });
    console.log('[Ellen TTS] nota de voz enviada OK', buf.length, 'bytes');
    return true;
  } catch (e) {
    console.error('Ellen TTS error:', e?.message || e);
    return false;
  }
}

async function speak(ctx, t, forceVoice = false) {
  const decor = require('./decor');
  const bubbles = String(t).split(/\s*\|\|\s*/).map((x) => x.trim()).filter(Boolean).slice(0, 3);
  if (!bubbles.length) return;
  const chat = db.chat(ctx.from);
  // Por defecto SIEMPRE manda nota de voz (salvo .ellenvozmode off)
  const voiceOn = chat.ellenVoice !== false;
  const doVoice = voiceOn; // siempre si está activado

  for (let i = 0; i < bubbles.length; i++) {
    const b = decor.clean ? decor.clean(bubbles[i]) : bubbles[i];
    // Simula "escribiendo..." y responde rápido (máx ~0.8s)
    const delay = Math.min(800, 250 + Math.min(b.length, 80) * 6);
    await typing(ctx, delay);
    if (i === 0) await (ctx.replyLongPlain || ctx.replyLong || ctx.reply)(b);
    else await ctx.sock.sendMessage(ctx.from, { text: b });
    await paused(ctx);
  }
  if (doVoice && bubbles[0]) {
    const main = (decor.clean ? decor.clean(bubbles[0]) : bubbles[0]);
    if (main.length >= 3 && main.length <= 280) {
      const ok = await sendVoice(ctx, main);
      if (!ok) console.error('[Ellen] no se pudo enviar la nota de voz');
    }
  }
}

async function tryRunCommand(ctx, text) {
  try {
    const r = miku.route(text, ctx);
    if (!r || !r.cmd) return null;
    const cmd = loader.find(r.cmd);
    if (!cmd || !cmd.run) return null;

    if (cmd.owner || cmd.category === 'owner') {
      if (!isSharky(ctx)) return { denied: true, say: 'meh... eso solo lo puede pedir el dueño.' };
    }

    const say = r.say || 'meh... ok, ahí va.';
    await speak(ctx, say);
    const fake = {
      ...ctx,
      command: r.cmd,
      q: r.arg || '',
      args: (r.arg || '').split(/\s+/).filter(Boolean),
      text: (r.arg || ''),
    };
    await cmd.run(fake);
    return { ok: true };
  } catch (e) {
    console.error('Ellen cmd:', e?.message || e);
    return null;
  }
}

async function respond(ctx, text, opts = {}) {
  const ran = await tryRunCommand(ctx, text);
  if (ran?.ok) return;
  if (ran?.denied) return speak(ctx, ran.say);

  await typing(ctx, 400); // empieza a "escribir" de una
  // Solo un recordatorio interno si habla el dueño; la personalidad no cambia
  const who = isSharky(ctx) ? ' [Nota interna: habla Sharky, el dueño del bot. Sigue siendo perezosa.]' : '';
  const out = await ai.talk(
    `ellen|${ctx.from}`,
    `${ctx.pushName}: ${text}${who}`,
    SYSTEM,
    { temperature: 0.95, max: 280 }
  );
  await speak(ctx, out, !!opts.forceVoice);
}

async function auto(ctx) {
  const chat = db.chat(ctx.from);
  const mode = chat.ellenAuto || 'off';
  if (mode === 'off') return;

  const text = String(ctx.text || ctx.q || '').trim();
  if (!text || text.length < 2) return;
  if (/^[.\!\/#]/.test(text)) return;

  const me = num(ctx.sock?.user?.id);
  let addressed = /\bellen\b|\bjoe\b/i.test(text)
    || (ctx.mentioned || []).some((j) => num(j) === me)
    || num(ctx.quoted?.sender) === me;

  if (mode === 'on' && !addressed) return;
  if (mode === 'all' && !addressed && Math.random() > 0.10) return;

  try {
    await respond(ctx, text);
  } catch (e) {
    console.error('Ellen auto:', e?.message || e);
  }
}

async function respondWithVoice(ctx, text) {
  return respond(ctx, text, { forceVoice: true });
}

module.exports = { respond, auto, speak, respondWithVoice, SYSTEM, SHARKY_NUM };
