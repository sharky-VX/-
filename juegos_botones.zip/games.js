const U = require('../lib/utils');
const { sans, C } = require('../lib/deco');
const state = require('../lib/state');
const db = require('../lib/db');

const mk = (name, desc, usage, run, aliases = []) => ({ name, aliases, desc, usage, category: 'games', run });
const norm = (s) => U.strip(String(s || '').toLowerCase()).replace(/[^a-z0-9 ]/g, '').replace(/\s+/g, ' ').trim();
const decode = (s) =>
  String(s).replace(/&quot;/g, '"').replace(/&#039;/g, "'").replace(/&amp;/g, '&').replace(/&eacute;/g, 'é')
    .replace(/&ldquo;|&rdquo;/g, '"').replace(/&hellip;/g, '…').replace(/&[a-z]+;/g, '');

const CAPITALES = [['Venezuela', 'Caracas'], ['Colombia', 'Bogotá'], ['México', 'Ciudad de México'], ['Argentina', 'Buenos Aires'], ['Chile', 'Santiago'], ['Perú', 'Lima'], ['Brasil', 'Brasilia'], ['Uruguay', 'Montevideo'], ['Paraguay', 'Asunción'], ['Bolivia', 'Sucre'], ['Ecuador', 'Quito'], ['Cuba', 'La Habana'], ['España', 'Madrid'], ['Francia', 'París'], ['Italia', 'Roma'], ['Alemania', 'Berlín'], ['Portugal', 'Lisboa'], ['Reino Unido', 'Londres'], ['Japón', 'Tokio'], ['China', 'Pekín'], ['Rusia', 'Moscú'], ['Egipto', 'El Cairo'], ['Canadá', 'Ottawa'], ['Australia', 'Canberra'], ['Turquía', 'Ankara'], ['Grecia', 'Atenas'], ['Suecia', 'Estocolmo'], ['Noruega', 'Oslo'], ['Panamá', 'Ciudad de Panamá'], ['Costa Rica', 'San José']];
const EMOJIS = [['🦁👑', 'el rey leon'], ['🕷️🧑', 'spiderman'], ['🧙‍♂️💍', 'el señor de los anillos'], ['🚢🧊❤️', 'titanic'], ['🐠🔍', 'buscando a nemo'], ['🦇🧑', 'batman'], ['🧊👸', 'frozen'], ['🤖🚗', 'transformers'], ['🧞‍♂️🪔', 'aladdin'], ['🐀👨‍🍳', 'ratatouille'], ['🦈🌊', 'tiburon'], ['👻🚫', 'cazafantasmas'], ['⚡👓🧙', 'harry potter'], ['🏴‍☠️🌊', 'piratas del caribe'], ['🧸🤠', 'toy story']];
const PALABRAS = ['computadora', 'telefono', 'ventana', 'elefante', 'chocolate', 'mariposa', 'guitarra', 'biblioteca', 'aventura', 'tormenta', 'refrigerador', 'zapatilla', 'montaña', 'fantasma', 'universo', 'dinosaurio', 'cuaderno', 'bicicleta', 'pelicula', 'tiburon', 'galleta', 'camiseta', 'planeta', 'teclado', 'carretera', 'esqueleto', 'volcan', 'helado', 'cocodrilo', 'astronauta'];
const AHORCADO = ['programacion', 'whatsapp', 'servidor', 'internet', 'camarones', 'murcielago', 'pirata', 'calculadora', 'universidad', 'astronomia', 'mariposa', 'laberinto', 'diamante', 'tesoro', 'bandera'];
const HANG = ['😀', '😐', '😟', '😨', '😱', '💀'];

const startQA = (c, { question, answers, show, reward = 50, seconds = 30 }) => {
  state.games.set(c.from, { type: 'qa', answers: answers.map(norm), show, reward, expires: Date.now() + seconds * 1000 });
  return c.reply(`${question}\n\n💬 Responde con: *${c.prefix}resp <respuesta>*  (${seconds} s • 🪙 +${reward})`);
};

async function sendGameButtons(c, text, buttons) {
  const pfx = c.prefix || '.';
  const btns = buttons.slice(0, 3).map((b) => ({
    buttonId: b.id.startsWith(pfx) ? b.id : (pfx + b.id),
    buttonText: { displayText: String(b.text).slice(0, 20) },
    type: 1,
  }));
  try {
    await c.sock.sendMessage(c.from, {
      text,
      footer: 'SHARKNEX · Juegos',
      buttons: btns,
      headerType: 1,
    }, { quoted: c.m });
  } catch {
    const alt = buttons.map((b) => '• ' + (b.id.startsWith(pfx) ? b.id : pfx + b.id) + ' — ' + b.text).join('\n');
    await c.reply(text + '\n\n' + alt);
  }
}

const list = [
  mk('mate', 'Reto de matemáticas fácil', '', (c) => {
    const a = U.rand(2, 50), b = U.rand(2, 20), op = U.pick(['+', '-', '*']);
    const ans = op === '+' ? a + b : op === '-' ? a - b : a * b;
    return startQA(c, { question: `🧮 ¿Cuánto es *${a} ${op} ${b}*?`, answers: [ans], show: ans, reward: 40 });
  }, ['math']),

  mk('matedificil', 'Reto de matemáticas difícil', '', (c) => {
    const a = U.rand(11, 99), b = U.rand(11, 99), k = U.rand(2, 9);
    return startQA(c, { question: `🧠 ¿Cuánto es *(${a} × ${k}) + ${b}*?`, answers: [a * k + b], show: a * k + b, reward: 120, seconds: 45 });
  }),

  mk('trivia', 'Pregunta de trivia (en inglés)', '', async (c) => {
    const d = await U.getJson('https://opentdb.com/api.php?amount=1&type=multiple');
    const t = d.results?.[0];
    if (!t) return c.reply('⚠️ No pude cargar la trivia, intenta otra vez.');
    const opts = [...t.incorrect_answers, t.correct_answer].map(decode).sort(() => Math.random() - 0.5);
    const idx = opts.indexOf(decode(t.correct_answer)) + 1;
    return startQA(c, {
      question: `❓ *${decode(t.question)}*\n📂 ${decode(t.category)}\n\n${opts.map((o, i) => `${i + 1}. ${o}`).join('\n')}`,
      answers: [idx, decode(t.correct_answer)], show: `${idx}. ${decode(t.correct_answer)}`, reward: 80,
    });
  }),

  mk('quizcapital', 'Adivina la capital', '', (c) => {
    const [pais, cap] = U.pick(CAPITALES);
    return startQA(c, { question: `🌎 ¿Cuál es la capital de *${pais}*?`, answers: [cap], show: cap, reward: 60 });
  }, ['capitales']),

  mk('emojiquiz', 'Adivina la película por emojis', '', (c) => {
    const [e, a] = U.pick(EMOJIS);
    return startQA(c, { question: `🎬 ¿Qué película/personaje es?\n\n${e}`, answers: [a], show: a, reward: 70, seconds: 40 });
  }, ['adivinapeli']),

  mk('palabra', 'Ordena las letras de la palabra', '', (c) => {
    const w = U.pick(PALABRAS);
    let s = w;
    while (s === w) s = [...w].sort(() => Math.random() - 0.5).join('');
    return startQA(c, { question: `🔤 Ordena las letras:\n\n*${s.toUpperCase()}*`, answers: [w], show: w, reward: 60 });
  }),

  mk('resp', 'Responde al reto activo', '<respuesta>', (c) => {
    const g = state.games.get(c.from);
    if (!g || g.type !== 'qa') return c.reply('No hay reto activo. Usa .mate, .trivia, .quizcapital, .emojiquiz o .palabra');
    if (Date.now() > g.expires) {
      state.games.delete(c.from);
      return c.reply(`⌛ Se acabó el tiempo. Era: *${g.show}*`);
    }
    if (g.answers.includes(norm(c.q))) {
      state.games.delete(c.from);
      db.user(c.senderNum).coins += g.reward;
      db.save();
      return c.reply(`🎉 ¡Correcto, *${c.pushName}*! Ganas 🪙 *${g.reward}* monedas.`);
    }
    return c.reply('❌ Incorrecto, intenta de nuevo.');
  }, ['respuesta', 'r']),

  mk('adivina', 'Adivina el número del 1 al 100', '', (c) => {
    state.games.set(c.from, { type: 'num', answer: U.rand(1, 100), tries: 0 });
    c.reply('🔢 Pensé un número del *1 al 100*.\nUsa: .num <número>');
  }),

  mk('num', 'Intenta adivinar el número', '<número>', (c) => {
    const g = state.games.get(c.from);
    if (!g || g.type !== 'num') return c.reply('No hay partida. Usa .adivina');
    const n = parseInt(c.args[0]);
    if (isNaN(n)) return c.reply('Escribe un número. Ej: .num 50');
    g.tries++;
    if (n === g.answer) {
      state.games.delete(c.from);
      const reward = Math.max(10, 100 - g.tries * 10);
      db.user(c.senderNum).coins += reward;
      db.save();
      return c.reply(`🎉 ¡Era *${g.answer}*! Lo logró *${c.pushName}* en ${g.tries} intentos. 🪙 +${reward}`);
    }
    c.reply(n < g.answer ? '⬆️ Más alto' : '⬇️ Más bajo');
  }),

  mk('ahorcado', 'Juego del ahorcado', '', (c) => {
    const w = U.pick(AHORCADO);
    state.games.set(c.from, { type: 'hang', word: w, guessed: new Set(), lives: 6 });
    c.reply(`${HANG[0]} *AHORCADO*\n\n${'_ '.repeat(w.length)}\n\nVidas: ❤️×6\nUsa: .letra <letra>`);
  }),

  mk('letra', 'Adivina una letra del ahorcado', '<letra>', (c) => {
    const g = state.games.get(c.from);
    if (!g || g.type !== 'hang') return c.reply('No hay partida. Usa .ahorcado');
    const l = norm(c.args[0]).charAt(0);
    if (!/[a-z]/.test(l)) return c.reply('Escribe una letra. Ej: .letra a');
    if (g.guessed.has(l)) return c.reply('Esa letra ya la dijeron.');
    g.guessed.add(l);
    if (!g.word.includes(l)) g.lives--;
    const shown = [...g.word].map((x) => (g.guessed.has(x) ? x : '_')).join(' ');
    if (!shown.includes('_')) {
      state.games.delete(c.from);
      db.user(c.senderNum).coins += 100;
      db.save();
      return c.reply(`🎉 ¡Ganaron! La palabra era *${g.word}*. 🪙 +100 para ${c.pushName}`);
    }
    if (g.lives <= 0) {
      state.games.delete(c.from);
      return c.reply(`${HANG[5]} Perdieron. La palabra era *${g.word}*`);
    }
    c.reply(`${HANG[6 - g.lives]} ${shown}\n\nLetras: ${[...g.guessed].join(', ')}\nVidas: ${'❤️'.repeat(g.lives)}`);
  }),



  // ── Gusano / Snake ──
  mk('snake', 'Juego del gusano con pantalla y botones', 'menu | w/a/s/d | start', async (c) => {
    const key = c.from + ':snake';
    const arg = (c.args[0] || c.q || '').toLowerCase().trim();
    let g = state.games.get(key);
    const pfx = c.prefix || '.';
    const W = 8, H = 8;

    const draw = (g) => {
      const grid = Array.from({ length: H }, () => Array(W).fill('⬛'));
      grid[g.apple[1]][g.apple[0]] = '🍎';
      g.snake.forEach((s, i) => {
        if (s[1] >= 0 && s[1] < H && s[0] >= 0 && s[0] < W)
          grid[s[1]][s[0]] = i === 0 ? '🟢' : '🟩';
      });
      return grid.map((r) => r.join('')).join('\n');
    };
    const placeApple = (g) => {
      for (let t = 0; t < 80; t++) {
        const x = U.rand(0, W - 1), y = U.rand(0, H - 1);
        if (!g.snake.some((s) => s[0] === x && s[1] === y)) return [x, y];
      }
      return [0, 0];
    };
    const menu = async () => {
      const body = [
        '   ❀ 𓆩 ' + sans('snake') + ' 𓆪 ❀',
        '',
        '  Gusano · come manzanas',
        '  Elige velocidad / modo:',
        '',
        '   ❀',
      ].join('\n');
      return sendGameButtons(c, body, [
        { id: 'snake facil', text: '🌱 Fácil' },
        { id: 'snake medio', text: '⚔️ Medio' },
        { id: 'snake dificil', text: '🧠 Difícil' },
      ]);
    };

    if (!arg || arg === 'menu' || arg === 'help') return menu();

    if (['facil', 'medio', 'dificil', 'start', 'nueva', 'new', 'extremo'].includes(arg)) {
      const speed = arg === 'facil' ? 1 : arg === 'dificil' || arg === 'extremo' ? 3 : 2;
      g = {
        type: 'snake', speed, snake: [[3, 3], [2, 3], [1, 3]], dir: [1, 0],
        apple: [6, 3], score: 0, alive: true,
      };
      g.apple = placeApple(g);
      state.games.set(key, g);
      const body = [
        '   ❀ 𓆩 ' + sans('snake') + ' 𓆪 ❀',
        'Nivel: *' + arg + '*',
        '',
        draw(g),
        '',
        'Puntos: *0*',
        'Mueve con los botones o: ' + pfx + 'snake w/a/s/d',
        '   ❀',
      ].join('\n');
      return sendGameButtons(c, body, [
        { id: 'snake w', text: '⬆️' },
        { id: 'snake a', text: '⬅️' },
        { id: 'snake d', text: '➡️' },
      ]);
    }

    if (!g || !g.alive) {
      if (['w','a','s','d','up','down','left','right','s'].includes(arg)) return menu();
      return menu();
    }

    const map = {
      w: [0, -1], up: [0, -1], arriba: [0, -1],
      s: [0, 1], down: [0, 1], abajo: [0, 1],
      a: [-1, 0], left: [-1, 0], izq: [-1, 0], izquierda: [-1, 0],
      d: [1, 0], right: [1, 0], der: [1, 0], derecha: [1, 0],
    };
    if (!map[arg]) {
      const body = [draw(g), '', 'Puntos: *' + g.score + '*', '   ❀'].join('\n');
      return sendGameButtons(c, body, [
        { id: 'snake w', text: '⬆️' },
        { id: 'snake a', text: '⬅️' },
        { id: 'snake d', text: '➡️' },
      ]);
    }
    const nd = map[arg];
    if (!(nd[0] === -g.dir[0] && nd[1] === -g.dir[1])) g.dir = nd;

    const steps = g.speed || 1;
    for (let step = 0; step < steps; step++) {
      const head = g.snake[0];
      const nx = head[0] + g.dir[0];
      const ny = head[1] + g.dir[1];
      if (nx < 0 || ny < 0 || nx >= W || ny >= H || g.snake.some((s) => s[0] === nx && s[1] === ny)) {
        g.alive = false;
        state.games.set(key, g);
        return sendGameButtons(c, [
          '   ❀ 𓆩 ' + sans('snake') + ' 𓆪 ❀',
          '💀 Game Over · Puntos: *' + g.score + '*',
          '   ❀',
        ].join('\n'), [
          { id: 'snake facil', text: 'Otra Fácil' },
          { id: 'snake medio', text: 'Otra Media' },
          { id: 'snake dificil', text: 'Otra Difícil' },
        ]);
      }
      g.snake.unshift([nx, ny]);
      if (nx === g.apple[0] && ny === g.apple[1]) {
        g.score += 1;
        g.apple = placeApple(g);
      } else {
        g.snake.pop();
      }
    }
    state.games.set(key, g);
    const body = [draw(g), '', 'Puntos: *' + g.score + '*', '   ❀'].join('\n');
    return sendGameButtons(c, body, [
      { id: 'snake w', text: '⬆️' },
      { id: 'snake a', text: '⬅️' },
      { id: 'snake s', text: '⬇️' },
    ]);
  }, ['gusano', 'serpiente', 'snakegame']),

  // ── Ajedrez con niveles IA (botones) ──
  mk('ajedrez', 'Ajedrez vs IA o rival · pantalla con niveles', 'menu | facil|medio|dificil|extremo | e2e4', async (c) => {
    const key = c.from + ':chess';
    const arg = (c.q || c.args.join(' ') || '').trim().toLowerCase();
    let g = state.games.get(key);
    const pfx = c.prefix || '.';

    const pieces = {
      K: '♔', Q: '♕', R: '♖', B: '♗', N: '♘', P: '♙',
      k: '♚', q: '♛', r: '♜', b: '♝', n: '♞', p: '♟',
    };
    const startBoard = () => ([
      ['r','n','b','q','k','b','n','r'],
      ['p','p','p','p','p','p','p','p'],
      ['','','','','','','',''],
      ['','','','','','','',''],
      ['','','','','','','',''],
      ['','','','','','','',''],
      ['P','P','P','P','P','P','P','P'],
      ['R','N','B','Q','K','B','N','R'],
    ]);
    const draw = (board, turn, level) => {
      const files = '  a b c d e f g h';
      const rows = board.map((row, i) => (8 - i) + ' ' + row.map((c) => pieces[c] || '·').join(' '));
      return [
        '   ❀ 𓆩 ' + sans('ajedrez') + ' 𓆪 ❀',
        level ? ('Nivel IA: *' + level + '*') : '',
        files,
        ...rows,
        files,
        '',
        'Turno: *' + (turn === 'w' ? 'Blancas (tú)' : 'Negras (IA)') + '*',
        'Mueve: ' + pfx + 'ajedrez e2e4',
        '   ❀',
      ].filter(Boolean).join('\n');
    };
    const parseSq = (s) => {
      if (!/^[a-h][1-8]$/i.test(s)) return null;
      return [8 - parseInt(s[1], 10), s.toLowerCase().charCodeAt(0) - 97];
    };
    const isWhite = (p) => p && p === p.toUpperCase();
    const genMoves = (board, whiteTurn) => {
      const moves = [];
      for (let r = 0; r < 8; r++) for (let f = 0; f < 8; f++) {
        const p = board[r][f];
        if (!p || isWhite(p) !== whiteTurn) continue;
        const pl = p.toLowerCase();
        const add = (r2, f2) => {
          if (r2 < 0 || r2 > 7 || f2 < 0 || f2 > 7) return;
          const t = board[r2][f2];
          if (t && isWhite(t) === whiteTurn) return;
          moves.push({ r, f, r2, f2, cap: !!t });
        };
        if (pl === 'p') {
          const dir = whiteTurn ? -1 : 1;
          if (!board[r + dir]?.[f]) {
            add(r + dir, f);
            if ((whiteTurn && r === 6) || (!whiteTurn && r === 1)) {
              if (!board[r + dir * 2]?.[f]) add(r + dir * 2, f);
            }
          }
          for (const df of [-1, 1]) {
            const t = board[r + dir]?.[f + df];
            if (t && isWhite(t) !== whiteTurn) add(r + dir, f + df);
          }
        } else if (pl === 'n') {
          for (const [dr, df] of [[-2,-1],[-2,1],[-1,-2],[-1,2],[1,-2],[1,2],[2,-1],[2,1]]) add(r + dr, f + df);
        } else if (pl === 'k') {
          for (let dr = -1; dr <= 1; dr++) for (let df = -1; df <= 1; df++) if (dr || df) add(r + dr, f + df);
        } else {
          const rays = pl === 'r' ? [[1,0],[-1,0],[0,1],[0,-1]]
            : pl === 'b' ? [[1,1],[1,-1],[-1,1],[-1,-1]]
            : pl === 'q' || pl === 'k' ? [[1,0],[-1,0],[0,1],[0,-1],[1,1],[1,-1],[-1,1],[-1,-1]]
            : [];
          for (const [dr, df] of rays) {
            for (let i = 1; i < 8; i++) {
              const r2 = r + dr * i, f2 = f + df * i;
              if (r2 < 0 || r2 > 7 || f2 < 0 || f2 > 7) break;
              const t = board[r2][f2];
              if (t && isWhite(t) === whiteTurn) break;
              add(r2, f2);
              if (t) break;
            }
          }
        }
      }
      return moves;
    };
    const applyMove = (board, m) => {
      const b = board.map((row) => row.slice());
      let piece = b[m.r][m.f];
      b[m.r2][m.f2] = piece;
      b[m.r][m.f] = '';
      if (piece === 'P' && m.r2 === 0) b[m.r2][m.f2] = 'Q';
      if (piece === 'p' && m.r2 === 7) b[m.r2][m.f2] = 'q';
      return b;
    };
    const aiMove = (board, level) => {
      let moves = genMoves(board, false);
      if (!moves.length) return null;
      if (level === 'facil') return moves[U.rand(0, moves.length - 1)];
      // prefer captures
      const caps = moves.filter((m) => m.cap);
      if (level === 'medio') {
        if (caps.length && Math.random() < 0.7) return caps[U.rand(0, caps.length - 1)];
        return moves[U.rand(0, moves.length - 1)];
      }
      // dificil / extremo: capturas primero, si no random "central"
      if (caps.length) return caps[U.rand(0, caps.length - 1)];
      moves.sort((a, b) => {
        const ca = Math.abs(a.r2 - 3.5) + Math.abs(a.f2 - 3.5);
        const cb = Math.abs(b.r2 - 3.5) + Math.abs(b.f2 - 3.5);
        return ca - cb;
      });
      return moves[0];
    };

    const showMenu = () => sendGameButtons(c, [
      '   ❀ 𓆩 ' + sans('ajedrez') + ' 𓆪 ❀',
      '',
      '  ♔  Ajedrez · vs Inteligencia Artificial',
      '  Selecciona el nivel de la IA:',
      '',
      '  🌱 Fácil — movimientos sencillos',
      '  ⚔️ Medio — busca buenas jugadas',
      '  🧠 Difícil — analiza posiciones',
      '  👑 Extremo — máxima agresividad',
      '',
      '   ❀',
    ].join('\n'), [
      { id: 'ajedrez facil', text: '🌱 Fácil' },
      { id: 'ajedrez medio', text: '⚔️ Medio' },
      { id: 'ajedrez dificil', text: '🧠 Difícil' },
    ]);

    if (!arg || arg === 'menu' || arg === 'help' || arg === 'start') return showMenu();
    if (/resign|rendirse|salir/.test(arg)) {
      state.games.delete(key);
      return c.reply(C.quote + 'Partida cancelada.');
    }

    if (['facil', 'medio', 'dificil', 'extremo', 'easy', 'hard'].includes(arg.split(/\s+/)[0])) {
      const level = arg.split(/\s+/)[0]
        .replace('easy', 'facil').replace('hard', 'dificil');
      g = { type: 'chess', board: startBoard(), turn: 'w', level, white: c.senderNum };
      state.games.set(key, g);
      return sendGameButtons(c, draw(g.board, g.turn, g.level) + '\n\nEres *Blancas*. Ej: ' + pfx + 'ajedrez e2e4', [
        { id: 'ajedrez menu', text: 'MENÚ' },
        { id: 'ajedrez resign', text: 'Rendirse' },
        { id: 'ajedrez e2e4', text: 'e2e4' },
      ]);
    }

    if (!g) return showMenu();

    const mstr = arg.replace(/\s+/g, '');
    if (!/^[a-h][1-8][a-h][1-8]$/.test(mstr)) {
      return sendGameButtons(c, draw(g.board, g.turn, g.level), [
        { id: 'ajedrez menu', text: 'MENÚ' },
        { id: 'ajedrez resign', text: 'Rendirse' },
        { id: 'ajedrez e2e4', text: 'e2e4' },
      ]);
    }
    const from = parseSq(mstr.slice(0, 2));
    const to = parseSq(mstr.slice(2, 4));
    if (!from || !to) return c.reply(C.quote + 'Casilla invalida.');
    const [r1, f1] = from, [r2, f2] = to;
    const piece = g.board[r1][f1];
    if (!piece || !isWhite(piece)) return c.reply(C.quote + 'Elige una pieza blanca tuya.');
    // aceptar movimiento del jugador
    g.board = applyMove(g.board, { r: r1, f: f1, r2, f2 });
    g.turn = 'b';
    // IA
    const ai = aiMove(g.board, g.level || 'medio');
    let aiTxt = '';
    if (ai) {
      const files = 'abcdefgh';
      aiTxt = '\nIA juega: *' + files[ai.f] + (8 - ai.r) + files[ai.f2] + (8 - ai.r2) + '*';
      g.board = applyMove(g.board, ai);
    } else {
      aiTxt = '\n¡La IA no tiene movimientos! Ganas.';
    }
    g.turn = 'w';
    state.games.set(key, g);
    return sendGameButtons(c, draw(g.board, g.turn, g.level) + '\nTu jugada: *' + mstr + '*' + aiTxt, [
      { id: 'ajedrez menu', text: 'MENÚ' },
      { id: 'ajedrez resign', text: 'Rendirse' },
      { id: 'ajedrez e2e4', text: 'e2e4' },
    ]);
  }, ['chess', 'chessgame']),

  // ── 2048 con menu botones ──
  mk('2048', '2048 con pantalla y botones', 'menu | start | w/a/s/d', async (c) => {
    const key = c.from + ':2048';
    const arg = (c.args[0] || '').toLowerCase();
    let g = state.games.get(key);
    const empty = () => {
      const b = Array.from({ length: 4 }, () => Array(4).fill(0));
      const add = () => {
        const free = [];
        for (let y = 0; y < 4; y++) for (let x = 0; x < 4; x++) if (!b[y][x]) free.push([x, y]);
        if (!free.length) return;
        const [x, y] = free[U.rand(0, free.length - 1)];
        b[y][x] = Math.random() < 0.9 ? 2 : 4;
      };
      add(); add();
      return b;
    };
    const draw = (b, score) => {
      const cell = (n) => (n ? String(n).padStart(4, ' ') : '  · ');
      return [
        '   ❀ 𓆩 ' + sans('2048') + ' 𓆪 ❀',
        ...b.map((r) => r.map(cell).join('')),
        'Puntos: *' + score + '*',
        '   ❀',
      ].join('\n');
    };
    const slide = (row) => {
      const a = row.filter((x) => x);
      for (let i = 0; i < a.length - 1; i++) {
        if (a[i] === a[i + 1]) { a[i] *= 2; a[i + 1] = 0; }
      }
      const b = a.filter((x) => x);
      while (b.length < 4) b.push(0);
      return b;
    };
    if (!arg || arg === 'menu' || arg === 'help') {
      return sendGameButtons(c, [
        '   ❀ 𓆩 ' + sans('2048') + ' 𓆪 ❀',
        '',
        '  Une números hasta 2048',
        '  Pulsa *Jugar* para empezar',
        '',
        '   ❀',
      ].join('\n'), [
        { id: '2048 start', text: '🎮 Jugar' },
        { id: '2048 menu', text: 'MENÚ' },
      ]);
    }
    if (arg === 'start' || arg === 'nueva') {
      g = { type: '2048', board: empty(), score: 0 };
      state.games.set(key, g);
      return sendGameButtons(c, draw(g.board, g.score), [
        { id: '2048 w', text: '⬆️' },
        { id: '2048 a', text: '⬅️' },
        { id: '2048 d', text: '➡️' },
      ]);
    }
    if (!g) {
      return sendGameButtons(c, 'No hay partida. Pulsa Jugar.', [
        { id: '2048 start', text: '🎮 Jugar' },
      ]);
    }
    const map = { w: 'up', s: 'down', a: 'left', d: 'right', up: 'up', down: 'down', left: 'left', right: 'right' };
    const dir = map[arg];
    if (!dir) {
      return sendGameButtons(c, draw(g.board, g.score), [
        { id: '2048 w', text: '⬆️' },
        { id: '2048 a', text: '⬅️' },
        { id: '2048 s', text: '⬇️' },
      ]);
    }
    let b = g.board.map((r) => r.slice());
    if (dir === 'left') b = b.map(slide);
    if (dir === 'right') b = b.map((r) => slide(r.slice().reverse()).reverse());
    if (dir === 'up') {
      for (let x = 0; x < 4; x++) {
        const col = slide([b[0][x], b[1][x], b[2][x], b[3][x]]);
        for (let y = 0; y < 4; y++) b[y][x] = col[y];
      }
    }
    if (dir === 'down') {
      for (let x = 0; x < 4; x++) {
        const col = slide([b[3][x], b[2][x], b[1][x], b[0][x]]);
        for (let y = 0; y < 4; y++) b[3 - y][x] = col[y];
      }
    }
    let sum = 0; b.forEach((r) => r.forEach((n) => { sum += n; }));
    g.score = sum;
    const free = [];
    for (let y = 0; y < 4; y++) for (let x = 0; x < 4; x++) if (!b[y][x]) free.push([x, y]);
    if (free.length) {
      const [x, y] = free[U.rand(0, free.length - 1)];
      b[y][x] = Math.random() < 0.9 ? 2 : 4;
    }
    g.board = b;
    state.games.set(key, g);
    return sendGameButtons(c, draw(g.board, g.score), [
      { id: '2048 w', text: '⬆️' },
      { id: '2048 a', text: '⬅️' },
      { id: '2048 d', text: '➡️' },
    ]);
  }, ['juego2048']),

  mk('rendirse', 'Termina el juego activo del chat', '', (c) => {
    const g = state.games.get(c.from);
    if (!g) return c.reply('No hay juego activo.');
    state.games.delete(c.from);
    c.reply(`🏳️ Juego terminado.${g.show ? ` Era: *${g.show}*` : g.word ? ` Era: *${g.word}*` : g.answer ? ` Era: *${g.answer}*` : ''}`);
  }, ['giveup']),
];

module.exports = list;
