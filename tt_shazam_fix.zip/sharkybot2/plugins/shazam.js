// ═══════════════════════════════════════════════
//  SHAZAM — Reconoce musica (decoracion menu)
// ═══════════════════════════════════════════════
const fs = require('fs');
const path = require('path');
const os = require('os');
const axios = require('axios');
const config = require('../config');
const U = require('../lib/utils');
const { card, wrap } = require('../lib/deco');

const mk = (name, desc, usage, run, aliases = [], extra = {}) => ({
  name, aliases, desc, usage, category: 'downloads', run, ...extra,
});

async function extractAudioBuffer(ctx) {
  const media = await ctx.getMedia(['audio', 'video', 'document', 'ptt']);
  if (!media || !media.buffer) return null;
  let buf = media.buffer;
  const mime = (media.mimetype || '').toLowerCase();

  if (mime.includes('video') || mime.includes('mp4') || mime.includes('mkv') || mime.includes('webm')) {
    const tmpIn = path.join(os.tmpdir(), 'shz_in_' + Date.now() + '.mp4');
    const tmpOut = path.join(os.tmpdir(), 'shz_out_' + Date.now() + '.mp3');
    try {
      fs.writeFileSync(tmpIn, buf);
      const { execFile } = require('child_process');
      const { promisify } = require('util');
      const exec = promisify(execFile);
      await exec('ffmpeg', ['-y', '-i', tmpIn, '-t', '25', '-vn', '-acodec', 'libmp3lame', '-q:a', '4', tmpOut], { timeout: 90000 });
      buf = fs.readFileSync(tmpOut);
    } catch (e) {
      console.error('ffmpeg shazam:', e?.message || e);
    } finally {
      try { fs.unlinkSync(tmpIn); } catch {}
      try { fs.unlinkSync(tmpOut); } catch {}
    }
  }
  if (buf.length > 2.5 * 1024 * 1024) buf = buf.slice(0, 2.5 * 1024 * 1024);
  return buf;
}

async function recognize(buf) {
  const token = (config.auddKey || process.env.AUDD_API_TOKEN || '').trim();
  const form = new FormData();
  form.append('file', new Blob([buf], { type: 'audio/mpeg' }), 'sample.mp3');
  form.append('return', 'apple_music,spotify');
  if (token) form.append('api_token', token);
  const { data } = await axios.post('https://api.audd.io/', form, {
    timeout: 45000,
    maxContentLength: 15 * 1024 * 1024,
  });
  if (!data || data.status !== 'success' || !data.result) {
    throw new Error(data?.error?.error_message || data?.status || 'sin resultado');
  }
  return data.result;
}

function coverUrl(result) {
  try {
    const art = result.apple_music?.artwork;
    if (art && art.url) {
      return String(art.url).replace('{w}', '600').replace('{h}', '600');
    }
  } catch {}
  try {
    const imgs = result.spotify?.album?.images;
    if (imgs && imgs[0] && imgs[0].url) return imgs[0].url;
  } catch {}
  return '';
}

async function fetchTrackAudio(title, artist) {
  const q = [title, artist].filter(Boolean).join(' ');
  try {
    const yt = require('../lib/ytdlp');
    const hits = await yt.search(q + ' audio oficial', 5);
    if (!hits || !hits.length) {
      const hits2 = await yt.search(q, 5);
      if (!hits2 || !hits2.length) return null;
      hits.push(...hits2);
    }
    for (const h of hits.slice(0, 3)) {
      try {
        const got = await yt.download(h.url, { audio: true });
        if (got && got.file) {
          const buf = fs.readFileSync(got.file);
          try { got.cleanup && got.cleanup(); } catch {}
          if (buf && buf.length > 5000) return { buf, title: h.title || title, url: h.url };
        }
      } catch (e) {
        console.error('shazam yt item:', e?.message || e);
      }
    }
  } catch (e) {
    console.error('shazam audio fetch:', e?.message || e);
  }
  return null;
}

module.exports = [
  mk('shazam', 'Reconoce la musica de un audio o video (responde al mensaje)', '', async (c) => {
    const buf = await extractAudioBuffer(c);
    if (!buf) {
      return c.reply(wrap(
        'Responde a un audio o video con:\n' + c.prefix + 'shazam\n\nTe digo el nombre y mando el audio completo.',
        'shazam'
      ));
    }
    await c.react('🔎');
    let result;
    try {
      result = await recognize(buf);
    } catch (e) {
      console.error('shazam:', e?.message || e);
      const hint = /token|auth|limit/i.test(String(e.message || ''))
        ? '\n\nOpcional: key gratis audd.io en config.auddKey'
        : '';
      return c.reply(wrap('No pude reconocer la musica. Usa un audio mas claro.' + hint, 'shazam'));
    }

    const title = result.title || 'Desconocida';
    const artist = result.artist || result.artist_name || '';
    const album = result.album || result.spotify?.album?.name || '';
    const release = result.release_date || '';
    const spotify = result.spotify?.external_urls?.spotify || '';
    const apple = result.apple_music?.url || '';
    const cover = coverUrl(result);

    const cap = card('shazam', [
      'Titulo ── ' + title,
      artist ? ('Artista ── ' + artist) : '',
      album ? ('Album ── ' + album) : '',
      release ? ('Fecha ── ' + release) : '',
      spotify ? ('Spotify ── ' + spotify) : '',
      apple ? ('Apple ── ' + apple) : '',
    ].filter(Boolean));

    // Portada + info
    if (cover) {
      try {
        const img = await U.getBuffer(cover, { timeout: 20000 });
        await c.sock.sendMessage(c.from, { image: img, caption: cap }, { quoted: c.m });
      } catch {
        await c.reply(cap);
      }
    } else {
      await c.reply(cap);
    }

    await c.react('⏳');
    const audio = await fetchTrackAudio(title, artist);
    if (audio && audio.buf) {
      await c.sock.sendMessage(c.from, {
        audio: audio.buf,
        mimetype: 'audio/mpeg',
        fileName: (title + '.mp3').replace(/[^\w\s\.\-]/g, '').slice(0, 80),
      }, { quoted: c.m }).catch(async () => {
        await c.sock.sendMessage(c.from, {
          document: audio.buf,
          mimetype: 'audio/mpeg',
          fileName: 'cancion.mp3',
          caption: card('shazam', [title, artist]),
        }, { quoted: c.m });
      });
      await c.react('✅');
    } else {
      await c.reply(wrap('Reconocida: ' + title + (artist ? ' — ' + artist : '') + '\nNo pude bajar el audio completo. Usa .play ' + title, 'shazam'));
      await c.react('✅');
    }
  }, ['queescancion', 'reconocermusica', 'whatmusic', 'songfind']),
];
