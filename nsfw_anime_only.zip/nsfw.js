// ═══════════════════════════════════════════════
//  NSFW oculto (.menu2) — SHARKNEX
//  Reacciones GIF + buscadores 10 links + botones + descarga
// ═══════════════════════════════════════════════
const axios = require('axios');
const fs = require('fs');
const U = require('../lib/utils');
const media = require('../lib/media');
const db = require('../lib/db');
const config = require('../config');
const { sans, C } = require('../lib/deco');
const { registry } = require('../lib/loader');
const yt = require('../lib/ytdlp');

const mk = (name, desc, usage, run, aliases = []) => ({
  name, aliases, desc, usage, category: 'nsfw', hidden: true, run,
});

const tag = (j) => '@' + String(j).split('@')[0].split(':')[0];
const pendingNsfw = new Map();

async function sendAnimated(c, url, text, mentions = []) {
  const { sock, from, m } = c;
  let buf;
  try { buf = await U.getBuffer(url, { timeout: 45000 }); }
  catch { throw new Error('No pude descargar el media.'); }
  const height = Number(db.data.gifHeight || config.gifHeight || 1080);
  let mp4 = null;
  try { mp4 = await media.toMp4HD(buf, height, 'gif'); }
  catch { try { mp4 = await media.toMp4(buf, 'gif'); } catch {} }
  if (mp4) {
    return sock.sendMessage(from, {
      video: mp4, caption: text, gifPlayback: true, mimetype: 'video/mp4', mentions,
    }, { quoted: m });
  }
  try {
    return await sock.sendMessage(from, { image: buf, mimetype: 'image/gif', caption: text, mentions }, { quoted: m });
  } catch {
    return sock.sendMessage(from, { text: text + '\n\n(No pude animar el GIF)', mentions }, { quoted: m });
  }
}

async function sendMedia(c, url, caption, mentions = [], forceGif = false) {
  if (!url || !String(url).startsWith('http')) throw new Error('Sin contenido.');
  // Preferir siempre GIF animado (como el bot del ejemplo)
  if (forceGif || /\.(gif|webm|mp4)(\?|$)/i.test(url) || /gif|nekobot|waifu|rule34/i.test(url)) {
    try { return await sendAnimated(c, url, caption, mentions); } catch (e) {
      console.error('sendAnimated fail:', e.message || e);
    }
  }
  try {
    const buf = await U.getBuffer(url, { timeout: 35000 });
    // Ultimo intento: convertir cualquier imagen a "gif" mp4
    if (forceGif) {
      try { return await sendAnimated(c, url, caption, mentions); } catch {}
    }
    return await c.sock.sendMessage(c.from, { image: buf, caption, mentions }, { quoted: c.m });
  } catch (e) {
    return c.sock.sendMessage(c.from, { text: caption + '\n\n(No pude cargar el media)', mentions }, { quoted: c.m });
  }
}

async function tryUrl(fn) {
  try {
    const u = await fn();
    if (u && String(u).startsWith('http')) return u;
  } catch {}
  return null;
}

async function listMediaLinks(tags, n) {
  n = n || 10;
  const out = [];
  try {
    const { data } = await axios.get('https://api.rule34.xxx/index.php', {
      params: { page: 'dapi', s: 'post', q: 'index', json: 1, limit: n, tags: tags || 'hentai' },
      headers: { 'User-Agent': 'Mozilla/5.0' }, timeout: 20000,
    });
    if (Array.isArray(data)) {
      for (const p of data.slice(0, n)) {
        const u = p.file_url || p.sample_url;
        if (u) out.push({ title: String(p.tags || tags || 'media').split(' ').slice(0, 4).join(' '), url: u });
      }
    }
  } catch (e) { console.error('listMediaLinks', e.message || e); }
  return out;
}

const SRC = {
  // SOLO anime / hentai (nada de contenido real)
  waifu: async (cat) => (await U.getJson('https://api.waifu.pics/nsfw/' + cat))?.url,
  // waifu.pics categories: waifu, neko, trap, blowjob
  hmtai: async (cat) => {
    // hmtai.hatsunia.cfd — anime nsfw
    const d = await U.getJson('https://hmtai.hatsunia.cfd/v2/' + cat).catch(() => null);
    return d?.url || null;
  },
  r34: async (tags) => {
    const base = (tags || 'hentai') + ' -photo -realistic -3d -western rating:explicit';
    const { data } = await axios.get('https://api.rule34.xxx/index.php', {
      params: { page: 'dapi', s: 'post', q: 'index', json: 1, limit: 30, tags: base },
      headers: { 'User-Agent': 'Mozilla/5.0' }, timeout: 20000,
    });
    if (!Array.isArray(data) || !data.length) return null;
    // Preferir gif/webm/mp4 animados
    const anim = data.filter((p) => /\\.(gif|webm|mp4)(\\?|$)/i.test(p.file_url || p.sample_url || ''));
    const pool = anim.length ? anim : data;
    const p = pool[Math.floor(Math.random() * pool.length)];
    return p.file_url || p.sample_url || null;
  },
  gel: async (tags) => {
    const base = (tags || 'hentai') + ' -photo -realistic rating:explicit';
    const { data } = await axios.get('https://gelbooru.com/index.php', {
      params: { page: 'dapi', s: 'post', q: 'index', json: 1, limit: 30, tags: base },
      headers: { 'User-Agent': 'Mozilla/5.0' }, timeout: 20000,
    });
    const posts = (data && data.post) || data;
    if (!Array.isArray(posts) || !posts.length) return null;
    const anim = posts.filter((p) => /\\.(gif|webm|mp4)(\\?|$)/i.test(p.file_url || p.sample_url || ''));
    const pool = anim.length ? anim : posts;
    const p = pool[Math.floor(Math.random() * pool.length)];
    return p.file_url || p.sample_url || null;
  },
};

async function getNsfw() {
  const fns = Array.prototype.slice.call(arguments);
  for (let i = 0; i < fns.length; i++) {
    const u = await tryUrl(fns[i]);
    if (u) return u;
  }
  throw new Error('Ninguna API respondio. Intenta de nuevo.');
}

async function searchXnxx(query, limit) {
  limit = limit || 10;
  const links = [];
  try {
    const rows = await yt.search('xnxx:' + query, limit).catch(() => []);
    for (const r of rows || []) if (r.url) links.push({ title: (r.title || 'video').slice(0, 60), url: r.url });
  } catch {}
  if (links.length < limit) {
    try {
      const { data: html } = await axios.get('https://www.xnxx.com/search/' + encodeURIComponent(query), {
        headers: { 'User-Agent': 'Mozilla/5.0' }, timeout: 20000, responseType: 'text',
      });
      const re = /href="(\/video-[a-z0-9]+\/[^"]+)"[^>]*>([^<]{0,80})/gi;
      let m;
      const seen = new Set(links.map((l) => l.url));
      while ((m = re.exec(String(html))) && links.length < limit) {
        const url = 'https://www.xnxx.com' + m[1];
        if (seen.has(url)) continue;
        seen.add(url);
        links.push({ title: (m[2] || 'xnxx').replace(/\s+/g, ' ').trim().slice(0, 60) || 'xnxx video', url });
      }
    } catch (e) { console.error('xnxx search', e.message || e); }
  }
  while (links.length < limit) {
    const i = links.length + 1;
    links.push({
      title: 'xnxx #' + i + ' · ' + query,
      url: 'https://www.xnxx.com/search/' + encodeURIComponent(query) + (i > 1 ? '/' + i : ''),
    });
  }
  return links.slice(0, limit);
}

async function searchXvideos(query, limit) {
  limit = limit || 10;
  const links = [];
  try {
    const rows = await yt.search('xvideos:' + query, limit).catch(() => []);
    for (const r of rows || []) if (r.url) links.push({ title: (r.title || 'video').slice(0, 60), url: r.url });
  } catch {}
  if (links.length < limit) {
    try {
      const { data: html } = await axios.get('https://www.xvideos.com/?k=' + encodeURIComponent(query), {
        headers: { 'User-Agent': 'Mozilla/5.0' }, timeout: 20000, responseType: 'text',
      });
      const re = /href="(\/video\.[^"]+)"[^>]*title="([^"]+)"/gi;
      let m;
      const seen = new Set(links.map((l) => l.url));
      while ((m = re.exec(String(html))) && links.length < limit) {
        const url = 'https://www.xvideos.com' + m[1];
        if (seen.has(url)) continue;
        seen.add(url);
        links.push({ title: (m[2] || 'xvideos').slice(0, 60), url });
      }
    } catch (e) { console.error('xvideos search', e.message || e); }
  }
  while (links.length < limit) {
    const i = links.length + 1;
    links.push({
      title: 'xvideos #' + i + ' · ' + query,
      url: 'https://www.xvideos.com/?k=' + encodeURIComponent(query) + (i > 1 ? '&p=' + (i - 1) : ''),
    });
  }
  return links.slice(0, limit);
}

async function searchHentaila(query, limit) {
  limit = limit || 10;
  const links = [];
  try {
    const { data: html } = await axios.get('https://hentaila.com/search?q=' + encodeURIComponent(query), {
      headers: { 'User-Agent': 'Mozilla/5.0' }, timeout: 18000, responseType: 'text',
    });
    const re = /href="(\/media\/[a-z0-9-]+)"/gi;
    let m;
    const seen = new Set();
    while ((m = re.exec(String(html))) && links.length < limit) {
      const path = m[1];
      if (seen.has(path)) continue;
      seen.add(path);
      const slug = path.replace('/media/', '').replace(/-/g, ' ');
      links.push({ title: slug.slice(0, 60), url: 'https://hentaila.com' + path });
    }
  } catch (e) { console.error('hentaila', e.message || e); }
  if (!links.length) {
    links.push({ title: query, url: 'https://hentaila.com/search?q=' + encodeURIComponent(query) });
  }
  return links.slice(0, limit);
}

function formatLinkList(title, query, links, prefix) {
  const lines = [
    '   ❀ 𓆩 ' + sans(title) + ' 𓆪 ❀',
    '',
    'Busqueda: ' + query,
    'Resultados: ' + links.length,
    '',
  ];
  links.forEach((l, i) => {
    lines.push((i + 1) + '. ' + (l.title || 'video').slice(0, 50));
    lines.push('   ' + l.url);
    lines.push('');
  });
  lines.push('> 𓆩✰𓆪 Botones abajo o ' + prefix + 'nsfwpick <n>');
  lines.push('   ❀');
  return lines.join('\n');
}

async function sendLinkButtons(c, title, query, links) {
  pendingNsfw.set(c.from, { links, at: Date.now(), query, source: title });
  const caption = formatLinkList(title, query, links, c.prefix || '.');
  const pfx = c.prefix || '.';
  const chunks = [];
  for (let i = 0; i < links.length; i += 3) {
    chunks.push(links.slice(i, i + 3).map((l, j) => ({ idx: i + j + 1, title: l.title, url: l.url })));
  }
  const firstBtns = (chunks[0] || []).map((l) => ({
    buttonId: pfx + 'nsfwpick ' + l.idx,
    buttonText: { displayText: 'Video ' + l.idx },
    type: 1,
  }));
  try {
    await c.sock.sendMessage(c.from, {
      text: caption,
      footer: 'SHARKNEX NSFW',
      buttons: firstBtns,
      headerType: 1,
    }, { quoted: c.m });
  } catch (e) {
    console.error('nsfw buttons:', e.message || e);
    await c.reply(caption);
  }
  for (let ci = 1; ci < chunks.length; ci++) {
    const btns = chunks[ci].map((l) => ({
      buttonId: pfx + 'nsfwpick ' + l.idx,
      buttonText: { displayText: 'Video ' + l.idx },
      type: 1,
    }));
    const labels = chunks[ci].map((l) => 'Video ' + l.idx).join(' · ');
    try {
      await c.sock.sendMessage(c.from, {
        text: '   ❀ 𓆩 ' + sans('mas videos') + ' 𓆪 ❀\n  ' + labels,
        footer: 'SHARKNEX',
        buttons: btns,
        headerType: 1,
      }, { quoted: c.m });
    } catch {
      await c.reply('Mas: ' + chunks[ci].map((l) => pfx + 'nsfwpick ' + l.idx).join(' · '));
    }
  }
}

async function sendPickedVideo(c, item, n) {
  await c.reply(C.quote + 'Descargando video ' + n + ' (max calidad disponible)...');
  const url = item.url;
  if (/\.(mp4|webm|mkv|mov)(\?|$)/i.test(url) || /video\.(rule34|gelbooru)/i.test(url)) {
    try {
      const buf = await U.getBuffer(url, { timeout: 120000 });
      if (buf && buf.length > 1000) {
        return c.sock.sendMessage(c.from, {
          video: buf,
          caption: '*' + (item.title || 'video') + '*\n' + url,
          mimetype: 'video/mp4',
        }, { quoted: c.m });
      }
    } catch (e) { console.error('direct video', e.message || e); }
  }
  if (/\.(gif|jpe?g|png|webp)(\?|$)/i.test(url)) {
    try { return await sendMedia(c, url, '*' + (item.title || '') + '*\n' + url); } catch {}
  }
  try {
    const maxMB = Number(config.maxFileMB || 80);
    const d = await yt.download(url, {
      audio: false,
      height: 2160,
      maxMB,
      maxDuration: Number(config.maxDurationSec || 600),
    });
    const buf = fs.readFileSync(d.file);
    try {
      await c.sock.sendMessage(c.from, {
        video: buf,
        caption: '*' + (item.title || d.title || 'video') + '*\nCalidad: max (hasta 4K si existe)\n' + url,
        mimetype: 'video/mp4',
      }, { quoted: c.m });
    } finally {
      try { d.cleanup(); } catch {}
    }
    return;
  } catch (e) {
    console.error('yt download nsfw', e.message || e);
    return c.reply(
      C.quote + 'No pude traer el archivo (peso/bloqueo/sitio).\nAbre:\n' + url + '\n\n' + String(e.message || e).slice(0, 120)
    );
  }
}

const REACTS = [
  // Solo anime/hentai GIF. Frase: "*Sharky* hizo cum a @user"
  ['anal', 'hizo anal a', 'se puso en modo anal', [], [
    () => SRC.r34('animated anal hentai'), () => SRC.gel('animated anal'), () => SRC.hmtai('anal'),
  ]],
  ['blowjob', 'hizo blowjob a', 'esta mamando', ['mamar', 'bj'], [
    () => SRC.waifu('blowjob'), () => SRC.r34('animated blowjob hentai'), () => SRC.hmtai('blowjob'),
  ]],
  ['boobjob', 'hizo rusa a', 'hizo una rusa', ['rusa'], [
    () => SRC.r34('animated paizuri hentai'), () => SRC.gel('paizuri animated'), () => SRC.hmtai('boobjob'),
  ]],
  ['cum', 'hizo cum a', 'se corrio', ['eyacular'], [
    () => SRC.r34('animated cum hentai'), () => SRC.gel('animated cum'), () => SRC.hmtai('cum'), () => SRC.waifu('blowjob'),
  ]],
  ['cummouth', 'hizo cum en la boca de', 'corrida en boca', [], [
    () => SRC.r34('cum_in_mouth hentai animated'), () => SRC.gel('cum_in_mouth'),
  ]],
  ['cumshot', 'hizo cumshot a', 'disparo cum', [], [
    () => SRC.r34('animated cumshot hentai'), () => SRC.gel('cumshot animated'),
  ]],
  ['fap', 'se la jala pensando en', 'se esta jalando', ['paja'], [
    () => SRC.r34('animated masturbation hentai'), () => SRC.gel('masturbation animated'), () => SRC.hmtai('ero'),
  ]],
  ['footjob', 'hizo footjob a', 'hizo footjob', [], [
    () => SRC.r34('animated footjob hentai'), () => SRC.gel('footjob animated'),
  ]],
  ['fuck', 'se la follo a', 'esta follando', ['coger'], [
    () => SRC.r34('animated sex hentai'), () => SRC.gel('sex animated'), () => SRC.hmtai('hentai'), () => SRC.waifu('waifu'),
  ]],
  ['grabboobs', 'le agarro las tetas a', 'agarra tetas', [], [
    () => SRC.r34('grabbing_breasts hentai'), () => SRC.hmtai('boobs'), () => SRC.waifu('waifu'),
  ]],
  ['grope', 'le manoseo a', 'manosea', [], [
    () => SRC.r34('groping hentai'), () => SRC.gel('groping'), () => SRC.hmtai('ass'),
  ]],
  ['handjob', 'hizo handjob a', 'hizo una paja', [], [
    () => SRC.r34('animated handjob hentai'), () => SRC.gel('handjob animated'),
  ]],
  ['lickass', 'le lamió el culo a', 'lame culo', ['lamercullo'], [
    () => SRC.r34('anilingus hentai'), () => SRC.gel('anilingus'),
  ]],
  ['lickdick', 'le lamió la polla a', 'lame polla', ['lamerpolla'], [
    () => SRC.r34('animated fellatio hentai'), () => SRC.waifu('blowjob'),
  ]],
  ['lickpussy', 'le lamió el coño a', 'lame coño', [], [
    () => SRC.r34('cunnilingus hentai'), () => SRC.gel('cunnilingus'),
  ]],
  ['sixnine', 'hizo el 69 con', 'modo 69', ['69'], [
    () => SRC.r34('69 hentai animated'), () => SRC.gel('69 animated'),
  ]],
  ['spank', 'le dio una nalgada a', 'nalgada', ['nalgada'], [
    () => SRC.r34('spanking hentai'), () => SRC.hmtai('spank'),
  ]],
  ['suckboobs', 'le chupo las tetas a', 'chupa tetas', ['chupartetas'], [
    () => SRC.r34('breast_sucking hentai'), () => SRC.hmtai('boobs'),
  ]],
  ['undress', 'encuero a', 'se desnudo', ['encuerar'], [
    () => SRC.r34('undressing hentai'), () => SRC.hmtai('hentai'), () => SRC.waifu('waifu'),
  ]],
  ['yuri', 'hizo tijeras con', 'modo yuri', ['tijeras'], [
    () => SRC.r34('yuri animated hentai'), () => SRC.gel('yuri'), () => SRC.hmtai('yuri'),
  ]],
];

const list = [];

for (const [name, withT, solo, aliases, sources] of REACTS) {
  list.push(mk(name, 'NSFW GIF: ' + name, '[@usuario | responder mensaje]', async (c) => {
    const target = (c.mentioned && c.mentioned[0]) || (c.quoted && c.quoted.sender);
    const who = c.pushName || 'Usuario';
    const mentions = [];
    let text;
    if (target) {
      mentions.push(c.sender, target);
      text = '*' + who + '* ' + withT + ' ' + tag(target);
    } else {
      mentions.push(c.sender);
      text = '*' + who + '* ' + solo;
    }
    const url = await getNsfw(...sources);
    return sendMedia(c, url, text, mentions, true);
  }, aliases));
}

list.push(mk('danbooru', 'Busca en Danbooru', '<tag>', async (c) => {
  const tags = (c.q || 'rating:explicit').trim();
  const { data } = await axios.get('https://danbooru.donmai.us/posts.json', {
    params: { tags, limit: 20 }, headers: { 'User-Agent': 'SharkyBot/4' }, timeout: 20000,
  });
  if (!Array.isArray(data) || !data.length) return c.reply('Sin resultados en Danbooru.');
  const p = data[Math.floor(Math.random() * data.length)];
  return sendMedia(c, p.file_url || p.large_file_url, C.quote + sans('danbooru') + ' · ' + tags);
}, ['dbooru']));

list.push(mk('gelbooru', 'Busca en Gelbooru', '<tag>', async (c) => {
  const tags = (c.q || 'hentai rating:explicit').trim();
  const url = await getNsfw(() => SRC.gel(tags));
  return sendMedia(c, url, C.quote + sans('gelbooru') + ' · ' + tags);
}, ['gbooru']));

list.push(mk('rule34', 'Rule34: 10 media + botones', '<tag>', async (c) => {
  const tags = (c.q || 'hentai animated').trim();
  await c.react('🔞');
  const links = await listMediaLinks(tags, 10);
  if (!links.length) return c.reply('Sin resultados en Rule34.');
  await sendLinkButtons(c, 'rule34', tags, links);
}, ['r34', 'r34vid']));

list.push(mk('xnxx', 'XNXX: 10 links + botones', '<query>', async (c) => {
  if (!c.q) return c.reply(C.quote + 'Ej: ' + c.prefix + 'xnxx hentai');
  await c.react('🔞');
  const links = await searchXnxx(c.q.trim(), 10);
  await sendLinkButtons(c, 'xnxx', c.q.trim(), links);
}, ['xxx']));

list.push(mk('xvideos', 'XVideos: 10 links + botones', '<query>', async (c) => {
  if (!c.q) return c.reply(C.quote + 'Ej: ' + c.prefix + 'xvideos hentai');
  await c.react('🔞');
  const links = await searchXvideos(c.q.trim(), 10);
  await sendLinkButtons(c, 'xvideos', c.q.trim(), links);
}, ['xv']));

list.push(mk('ph', 'Pornhub: 10 links + botones', '<query>', async (c) => {
  if (!c.q) return c.reply(C.quote + 'Ej: ' + c.prefix + 'ph hentai');
  await c.react('🔞');
  let links = [];
  try {
    const rows = await yt.search('pornhub:' + c.q.trim(), 10).catch(() => []);
    for (const r of rows || []) if (r.url) links.push({ title: (r.title || 'ph').slice(0, 60), url: r.url });
  } catch {}
  while (links.length < 10) {
    const i = links.length + 1;
    links.push({
      title: 'pornhub #' + i + ' · ' + c.q,
      url: 'https://www.pornhub.com/video/search?search=' + encodeURIComponent(c.q.trim()) + (i > 1 ? '&page=' + i : ''),
    });
  }
  await sendLinkButtons(c, 'pornhub', c.q.trim(), links.slice(0, 10));
}, ['pornhub']));

list.push(mk('hentaila', 'HentaiLA: 10 links + botones', '<titulo>', async (c) => {
  if (!c.q) return c.reply(C.quote + 'Ej: ' + c.prefix + 'hentaila overflow');
  await c.react('🔞');
  const links = await searchHentaila(c.q.trim(), 10);
  await sendLinkButtons(c, 'hentaila', c.q.trim(), links);
}, ['hla']));

list.push(mk('maplestar', 'Maplestar: 10 media + botones', '<nombre>', async (c) => {
  const q = (c.q || 'maplestar').trim();
  await c.react('🔞');
  let links = await listMediaLinks('maplestar ' + q, 10);
  if (!links.length) links = await listMediaLinks('maplestar', 10);
  if (!links.length) return c.reply(C.quote + 'Sin resultados. Prueba: ' + c.prefix + 'rule34 maplestar');
  await sendLinkButtons(c, 'maplestar', q, links);
}, ['maple']));

list.push(mk('nsfwpick', 'Descarga el video del boton o numero', '<numero>', async (c) => {
  const pack = pendingNsfw.get(c.from);
  if (!pack || !pack.links || !pack.links.length) {
    return c.reply(C.quote + 'No hay busqueda. Usa .xnxx / .xxx / .maplestar / .hentaila');
  }
  if (Date.now() - pack.at > 600000) {
    pendingNsfw.delete(c.from);
    return c.reply(C.quote + 'Lista expirada. Busca de nuevo.');
  }
  const n = parseInt(c.args[0] || c.q, 10);
  if (!n || n < 1 || n > pack.links.length) {
    return c.reply(C.quote + 'Elige 1-' + pack.links.length);
  }
  await sendPickedVideo(c, pack.links[n - 1], n);
}, ['nspick', 'picknsfw', 'elegirnsfw', 'video']));

list.push(mk('menu2', 'Menu oculto NSFW (18+)', '', async (c) => {
  const pfx = c.prefix || '.';
  const cmds = registry.list
    .filter((p) => p.category === 'nsfw' && p.name !== 'menu2')
    .sort((a, b) => a.name.localeCompare(b.name, 'es'));
  const lines = [
    '   ❀ 𓆩 ' + sans('CATEGORIA NSFW') + ' 𓆪 ❀',
    'Solo mayores de 18',
    '',
  ];
  for (const p of cmds) {
    const al = (p.aliases || []).slice(0, 2).map((a) => pfx + a).join(' · ');
    lines.push(pfx + p.name + (al ? ' · ' + al : ''));
    if (p.desc) lines.push('> ' + String(p.desc).slice(0, 50));
    lines.push('');
  }
  lines.push('   ❀');
  return c.reply(lines.join('\n'));
}, ['labiblia', 'nsfwmenu', 'menunsfw']));

module.exports = list;
