// ═══════════════════════════════════════════════
//  NSFW (oculto) — solo se ve con .menu2
//  Reacciones con mención + GIFs hentai HD
//  APIs con múltiples fallbacks + HentaiLA
//  SHARKNEX v4
// ═══════════════════════════════════════════════
const axios = require('axios');
const U = require('../lib/utils');
const media = require('../lib/media');
const db = require('../lib/db');
const config = require('../config');
const { sans, C } = require('../lib/deco');
const { registry } = require('../lib/loader');

const mk = (name, desc, usage, run, aliases = []) => ({
  name, aliases, desc, usage,
  category: 'nsfw',
  hidden: true,
  run,
});

const tag = (j) => '@' + String(j).split('@')[0].split(':')[0];

// ── Envío GIF HD ──
async function sendAnimated(c, url, text, mentions = []) {
  const { sock, from, m } = c;
  let buf;
  try {
    buf = await U.getBuffer(url, { timeout: 45000 });
  } catch (e) {
    throw new Error('No pude descargar el GIF. Prueba de nuevo.');
  }
  const height = Number(db.data.gifHeight || config.gifHeight || 1080);
  let mp4 = null, why = '';
  try { mp4 = await media.toMp4HD(buf, height, 'gif'); }
  catch (e) {
    why = String(e?.message || e);
    if (!/ffmpeg no est/i.test(why)) {
      try { mp4 = await media.toMp4(buf, 'gif'); } catch (e2) { why = String(e2?.message || e2); }
    }
  }
  if (mp4) {
    return sock.sendMessage(from, {
      video: mp4, caption: text, gifPlayback: true, mimetype: 'video/mp4', mentions,
    }, { quoted: m });
  }
  try {
    return await sock.sendMessage(from, {
      image: buf, mimetype: 'image/gif', caption: text, mentions,
    }, { quoted: m });
  } catch {
    return sock.sendMessage(from, { text: text + '\n\n(No pude animar el GIF)', mentions }, { quoted: m });
  }
}

async function sendMedia(c, url, caption, mentions = []) {
  if (!url || typeof url !== 'string' || !url.startsWith('http')) {
    throw new Error('La API no devolvió contenido válido.');
  }
  if (/\.gif(\?|$)/i.test(url) || /gif|webm/i.test(url)) {
    return sendAnimated(c, url, caption, mentions);
  }
  const buf = await U.getBuffer(url, { timeout: 35000 });
  return c.sock.sendMessage(c.from, { image: buf, caption, mentions }, { quoted: c.m });
}

async function tryUrl(fn) {
  try {
    const u = await fn();
    if (u && typeof u === 'string' && u.startsWith('http')) return u;
  } catch {}
  return null;
}

const SRC = {
  waifu: async (cat) => {
    const d = await U.getJson('https://api.waifu.pics/nsfw/' + cat);
    return d && d.url;
  },
  nekobot: async (type) => {
    const d = await U.getJson('https://nekobot.xyz/api/image?type=' + type);
    return d && d.message;
  },
  r34: async (tags) => {
    const { data } = await axios.get('https://api.rule34.xxx/index.php', {
      params: { page: 'dapi', s: 'post', q: 'index', json: 1, limit: 30, tags: tags || 'hentai' },
      headers: { 'User-Agent': 'Mozilla/5.0 (compatible; SharkyBot/4.0)' },
      timeout: 20000,
    });
    if (!Array.isArray(data) || !data.length) return null;
    const p = data[Math.floor(Math.random() * data.length)];
    return p.file_url || p.sample_url || null;
  },
  gel: async (tags) => {
    const { data } = await axios.get('https://gelbooru.com/index.php', {
      params: { page: 'dapi', s: 'post', q: 'index', json: 1, limit: 25, tags: tags || 'hentai rating:explicit' },
      headers: { 'User-Agent': 'Mozilla/5.0' },
      timeout: 20000,
    });
    const posts = (data && data.post) || data;
    if (!Array.isArray(posts) || !posts.length) return null;
    const p = posts[Math.floor(Math.random() * posts.length)];
    return p.file_url || p.sample_url || null;
  },
};

async function getNsfw() {
  const fns = Array.prototype.slice.call(arguments);
  for (let i = 0; i < fns.length; i++) {
    const u = await tryUrl(fns[i]);
    if (u) return u;
  }
  throw new Error('Ninguna API respondió ahora. Intenta de nuevo en unos segundos.');
}

// Reacciones NSFW
const REACTS = [
  ['fap', 'se la jala pensando en', 'se la está jalando', ['masturbar', 'jalarsela'], [
    function(){return SRC.waifu('blowjob');}, function(){return SRC.nekobot('pgif');}, function(){return SRC.r34('animated masturbation');}, function(){return SRC.gel('animated masturbation');}
  ]],
  ['fuck', 'se la folló a', 'se está follando a alguien', ['coger', 'follar', 'sex'], [
    function(){return SRC.waifu('blowjob');}, function(){return SRC.nekobot('hentai');}, function(){return SRC.r34('animated sex');}, function(){return SRC.gel('animated sex');}
  ]],
  ['blowjob', 'le hizo un blowjob a', 'está chupando', ['bj', 'chupar', 'oral'], [
    function(){return SRC.waifu('blowjob');}, function(){return SRC.nekobot('blowjob');}, function(){return SRC.r34('animated blowjob');}, function(){return SRC.gel('animated blowjob');}
  ]],
  ['anal', 'le metió por el culo a', 'está en modo anal', ['culo'], [
    function(){return SRC.nekobot('anal');}, function(){return SRC.r34('animated anal');}, function(){return SRC.gel('animated anal');}
  ]],
  ['cum', 'le rellenó de leche a', 'se corrió', ['leche', 'corrida'], [
    function(){return SRC.nekobot('cum');}, function(){return SRC.r34('animated cum');}, function(){return SRC.gel('animated cumshot');}
  ]],
  ['ahegao', 'le sacó cara ahegao a', 'puso cara ahegao', [], [
    function(){return SRC.nekobot('ahegao');}, function(){return SRC.r34('ahegao');}, function(){return SRC.gel('ahegao');}
  ]],
  ['boobs', 'le apretó las tetas a', 'muestra las tetas', ['tetas', 'tits'], [
    function(){return SRC.nekobot('boobs');}, function(){return SRC.r34('huge_breasts');}, function(){return SRC.gel('huge_breasts');}
  ]],
  ['ass', 'le miró el culo a', 'muestra el culo', ['culo', 'nalgas'], [
    function(){return SRC.nekobot('ass');}, function(){return SRC.r34('ass');}, function(){return SRC.gel('ass');}
  ]],
  ['pussy', 'le tocó el coño a', 'muestra el coño', ['coño', 'vagina'], [
    function(){return SRC.nekobot('pussy');}, function(){return SRC.r34('pussy');}, function(){return SRC.gel('pussy');}
  ]],
  ['tentacle', 'le atacó con tentáculos a', 'está siendo atacado por tentáculos', ['tentaculos'], [
    function(){return SRC.nekobot('tentacle');}, function(){return SRC.r34('tentacles');}, function(){return SRC.gel('tentacles');}
  ]],
  ['yuri', 'se enrolló con', 'está en modo yuri', ['lesbian'], [
    function(){return SRC.nekobot('yuri');}, function(){return SRC.r34('yuri');}, function(){return SRC.gel('yuri');}
  ]],
  ['trap', 'le reveló que es trap a', 'es un trap', ['femboy'], [
    function(){return SRC.waifu('trap');}, function(){return SRC.r34('trap');}, function(){return SRC.gel('trap');}
  ]],
  ['neko', 'neko NSFW con', 'neko NSFW', ['hneko', 'nekonsfw'], [
    function(){return SRC.waifu('neko');}, function(){return SRC.r34('catgirl');}, function(){return SRC.gel('cat_ears');}
  ]],
  ['waifu', 'waifu NSFW de', 'waifu NSFW', ['hwaifu', 'waifunsfw'], [
    function(){return SRC.waifu('waifu');}, function(){return SRC.r34('1girl');}, function(){return SRC.gel('1girl');}
  ]],
  ['hentai', 'le mandó hentai a', 'hentai random', ['h'], [
    function(){return SRC.nekobot('hentai');}, function(){return SRC.r34('hentai');}, function(){return SRC.gel('hentai');}
  ]],
  ['pgif', 'GIF porno para', 'GIF porno anime', ['gifnsfw', 'pornogif'], [
    function(){return SRC.nekobot('pgif');}, function(){return SRC.r34('animated');}, function(){return SRC.gel('animated');}
  ]],
];

const list = [];

for (let i = 0; i < REACTS.length; i++) {
  const name = REACTS[i][0], withT = REACTS[i][1], solo = REACTS[i][2], aliases = REACTS[i][3], sources = REACTS[i][4];
  list.push(mk(name, 'Reacción NSFW: ' + name, '[@usuario | responde]', (function(n, wt, so, srcs) {
    return async function(c) {
      const target = (c.mentioned && c.mentioned[0]) || (c.quoted && c.quoted.sender);
      const mentions = target ? [target] : [];
      const text = target ? ('*' + c.pushName + '* ' + wt + ' ' + tag(target)) : ('*' + c.pushName + '* ' + so);
      const url = await getNsfw.apply(null, srcs);
      return sendMedia(c, url, text, mentions);
    };
  })(name, withT, solo, sources), aliases));
}

list.push(mk('rule34', 'Rule34 por tags (hentai)', '<tags>', async function(c) {
  const tags = (c.q || 'hentai animated').trim();
  const url = await getNsfw(function(){return SRC.r34(tags);}, function(){return SRC.gel(tags);});
  return sendMedia(c, url, C.quote + sans('rule34') + ' · ' + tags);
}, ['r34']));

list.push(mk('gelbooru', 'Gelbooru por tags', '<tags>', async function(c) {
  const tags = (c.q || 'hentai rating:explicit').trim();
  const url = await getNsfw(function(){return SRC.gel(tags);});
  return sendMedia(c, url, C.quote + sans('gelbooru') + ' · ' + tags);
}, ['gel']));

list.push(mk('naranja', 'Fuente Naranja (waifu.pics)', '', async function(c) {
  const cats = ['waifu', 'neko', 'blowjob', 'trap'];
  const cat = cats[Math.floor(Math.random() * cats.length)];
  const url = await getNsfw(function(){return SRC.waifu(cat);}, function(){return SRC.r34(cat);});
  return sendMedia(c, url, C.quote + sans('naranja') + ' · ' + cat);
}, ['orange']));

list.push(mk('azul', 'Fuente Azul (nekobot)', '', async function(c) {
  const types = ['hentai', 'pgif', 'anal', 'boobs', 'ass', 'pussy', 'ahegao'];
  const t = types[Math.floor(Math.random() * types.length)];
  const url = await getNsfw(function(){return SRC.nekobot(t);}, function(){return SRC.r34(t);});
  return sendMedia(c, url, C.quote + sans('azul') + ' · ' + t);
}, ['blue']));

list.push(mk('roja', 'Fuente Roja (rule34/gelbooru)', '', async function(c) {
  const url = await getNsfw(
    function(){return SRC.r34('hentai animated -loli -shota');},
    function(){return SRC.gel('hentai animated -loli -shota');}
  );
  return sendMedia(c, url, C.quote + sans('roja'));
}, ['red']));

list.push(mk('hentaila', 'Busca serie en HentaiLA (portada + link)', '<nombre o link>', async function(c) {
  if (!c.q) return c.reply(C.quote + 'Escribe el nombre o pega el link.\nEj: ' + c.prefix + 'hentaila sexfriend');
  const q = c.q.trim();

  if (/hentaila\.com\/media\//i.test(q)) {
    const slug = (q.match(/\/media\/([a-z0-9-]+)/i) || [])[1];
    const cover = slug ? ('https://cdn.hentaila.com/covers/' + slug + '.jpg') : null;
    const caption = [C.ftop, C.fcat + '`' + sans('hentaila') + '`', '│ ✦ *Link:* ' + q, C.fbot].join('\n');
    if (cover) {
      try {
        const buf = await U.getBuffer(cover);
        return c.sock.sendMessage(c.from, { image: buf, caption: caption }, { quoted: c.m });
      } catch {}
    }
    return c.reply(caption);
  }

  try {
    const res = await axios.get('https://hentaila.com/search?q=' + encodeURIComponent(q), {
      headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36' },
      timeout: 18000,
      responseType: 'text',
    });
    const html = String(res.data);
    const m = html.match(/href="(\/media\/[a-z0-9-]+)"[\s\S]{0,400}?src="(https?:\/\/[^"]+)"/i) || html.match(/\/media\/([a-z0-9-]+)/i);
    if (!m) return c.reply('No encontré resultados en HentaiLA para: ' + q);

    const path = m[1].indexOf('/') === 0 ? m[1] : ('/media/' + m[1]);
    const cover = m[2] || ('https://cdn.hentaila.com/covers/' + m[1] + '.jpg');
    const url = 'https://hentaila.com' + path;
    const title = path.replace('/media/', '').replace(/-/g, ' ');

    const caption = [
      C.ftop,
      C.fcat + '`' + sans('hentaila') + '`',
      '│ ✦ *Serie:* ' + title,
      '│ ✦ *Busqueda:* ' + q,
      '│ ✦ *Link:* ' + url,
      C.fbot,
      C.quote + 'Abre el link para ver los episodios',
    ].join('\n');

    try {
      const buf = await U.getBuffer(cover);
      await c.sock.sendMessage(c.from, { image: buf, caption: caption }, { quoted: c.m });
    } catch {
      await c.reply(caption);
    }
  } catch (e) {
    return c.reply('Error HentaiLA: ' + String(e.message || e).slice(0, 140));
  }
}, ['hla', 'hentai.la', 'la']));

list.push(mk('maplestar', 'Maplestar (animaciones hentai)', '<nombre opcional>', async function(c) {
  const q = (c.q || 'maplestar').trim();
  try {
    const url = await getNsfw(
      function(){return SRC.r34('maplestar ' + q);},
      function(){return SRC.gel('maplestar ' + q);},
      function(){return SRC.r34('maplestar animated');}
    );
    const text = '*Maplestar* · ' + q + '\n' + C.quote + 'Patreon: https://www.patreon.com/Maplestar';
    return sendMedia(c, url, text);
  } catch {
    const text = [
      C.ftop,
      C.fcat + '`' + sans('maplestar') + '`',
      '│ ✦ Animaciones hentai de alta calidad',
      '│ ✦ Patreon: https://www.patreon.com/Maplestar',
      '│ ✦ Busca también: .rule34 maplestar',
      C.fbot,
    ].join('\n');
    return c.reply(text);
  }
}, ['maple']));

list.push(mk('hanime', 'Busca streaming hentai (HentaiLA / Hanime)', '<nombre>', async function(c) {
  if (!c.q) return c.reply(C.quote + 'Ej: ' + c.prefix + 'hanime overflow');
  const q = encodeURIComponent(c.q.trim());
  const text = [
    C.ftop,
    C.fcat + '`' + sans('streaming hentai') + '`',
    '│ ✦ *Busqueda:* ' + c.q,
    '│ ✦ HentaiLA: https://hentaila.com/search?q=' + q,
    '│ ✦ Hanime: https://hanime.tv/search?q=' + q,
    C.fbot,
    C.quote + 'Usa .hentaila <nombre> para portada + link directo',
  ].join('\n');
  return c.reply(text);
}, ['streaminghentai']));

list.push(mk('menu2', 'Menú oculto NSFW (18+)', '', async function(c) {
  const pfx = c.prefix || '.';
  const cmds = registry.list
    .filter(function(p) { return p.category === 'nsfw' && p.name !== 'menu2'; })
    .sort(function(a, b) { return a.name.localeCompare(b.name, 'es'); });

  const lines = [
    C.ftop,
    C.fcat + '`' + sans('menu nsfw') + '`',
    '│ ' + C.bul + ' *Solo mayores de 18*',
    '│ ' + C.bul + ' Categoría oculta · no aparece en .menu',
    '│ ' + C.bul + ' Responde a un mensaje o menciona a alguien',
    '│',
  ];

  for (let i = 0; i < cmds.length; i++) {
    const p = cmds[i];
    const al = (p.aliases || []).slice(0, 2).map(function(a) { return pfx + a; }).join(' / ');
    const names = al ? (pfx + p.name + ' / ' + al) : (pfx + p.name);
    lines.push('│ ' + C.bul + ' *' + names + '*');
    if (p.desc) lines.push('│    ˚ʚ ' + sans(String(p.desc).slice(0, 52)) + ' ɞ˚');
    lines.push('│');
  }

  lines.push(C.fbot);
  lines.push(C.quote + sans('Fuentes: waifu.pics · nekobot · rule34 · gelbooru · HentaiLA'));
  lines.push(C.quote + sans('Ejemplo: responde a alguien y pon .fap'));
  return c.reply(lines.join('\n'));
}, ['nsfwmenu', 'menunsfw', 'menu18']));

module.exports = list;
