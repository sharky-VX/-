// ═══════════════════════════════════════════════
//  SHAZAM — Reconoce musica de audio/video
//  Responde a un audio o video con .shazam
// ═══════════════════════════════════════════════
const fs = require('fs');
const path = require('path');
const os = require('os');
const axios = require('axios');
const config = require('../config');
const U = require('../lib/utils');

const mk = (name, desc, usage, run, aliases = [], extra = {}) => ({
  name, aliases, desc, usage, category: 'downloads', run, ...extra,
});

async function extractAudioBuffer(ctx) {
  // Media del mensaje citado o del propio mensaje
  const media = await ctx.getMedia(['audio', 'video', 'document', 'ptt']);
  if (!media || !media.buffer) return null;
  let buf = media.buffer;
  const mime = (media.mimetype || '').toLowerCase();

  // Si es video, extraer audio con ffmpeg si existe
  if (mime.includes('video') || mime.includes('mp4') || mime.includes('mkv')) {
    const tmpIn = path.join(os.tmpdir(), 'shz_in_' + Date.now() + '.mp4');
    const tmpOut = path.join(os.tmpdir(), 'shz_out_' + Date.now() + '.mp3');
    try {
      fs.writeFileSync(tmpIn, buf);
      const { execFile } = require('child_process');
      const { promisify } = require('util');
      const exec = promisify(execFile);
      await exec('ffmpeg', ['-y', '-i', tmpIn, '-t', '20', '-vn', '-acodec', 'libmp3lame', '-q:a', '5', tmpOut], { timeout: 60000 });
      buf = fs.readFileSync(tmpOut);
    } catch (e) {
      console.error('ffmpeg shazam:', e?.message || e);
      // seguir con buffer original por si audd lo acepta
    } finally {
      try { fs.unlinkSync(tmpIn); } catch {}
      try { fs.unlinkSync(tmpOut); } catch {}
    }
  }
  // AudD recomienda clips cortos: recortar buffer si es enorme (solo audio file size)
  if (buf.length > 2 * 1024 * 1024) {
    buf = buf.slice(0, 2 * 1024 * 1024);
  }
  return buf;
}

async function recognize(buf) {
  const token = (config.auddKey || process.env.AUDD_API_TOKEN || '').trim();
  const form = new FormData();
  const blob = new Blob([buf], { type: 'audio/mpeg' });
  form.append('file', blob, 'sample.mp3');
  form.append('return', 'apple_music,spotify');
  if (token) form.append('api_token', token);

  const { data } = await axios.post('https://api.audd.io/', form, {
    timeout: 45000,
    maxContentLength: 15 * 1024 * 1024,
  });

  if (!data || data.status !== 'success' || !data.result) {
    const msg = data?.error?.error_message || data?.status || 'sin resultado';
    throw new Error(String(msg));
  }
  return data.result;
}

async function fetchTrackAudio(title, artist) {
  const q = [title, artist].filter(Boolean).join(' ');
  try {
    const yt = require('../lib/ytdlp');
    const hits = await yt.search(q + ' audio', 3);
    if (!hits || !hits.length) return null;
    const url = hits[0].url;
    const got = await yt.download(url, { audio: true });
    if (!got || !got.file) return null;
    const buf = fs.readFileSync(got.file);
    try { got.cleanup && got.cleanup(); } catch {}
    return { buf, title: hits[0].title, url };
  } catch (e) {
    console.error('shazam audio fetch:', e?.message || e);
    return null;
  }
}

module.exports = [
  mk('shazam', 'Reconoce la musica de un audio o video (responde al mensaje)', '', async (c) => {
    const buf = await extractAudioBuffer(c);
    if (!buf) {
      return c.reply(
        'Responde a un *audio* o *video* con:\n' +
        c.prefix + 'shazam\n\n' +
        'Te digo el nombre de la cancion y te mando el audio.'
      );
    }
    await c.react('🔎');
    let result;
    try {
      result = await recognize(buf);
    } catch (e) {
      console.error('shazam:', e?.message || e);
      const hint = /token|auth|limit/i.test(String(e.message || ''))
        ? '\n\n(Opcional: pon tu key gratis de audd.io en config.auddKey)'
        : '';
      return c.reply('No pude reconocer la musica. Prueba con un audio mas claro o un trozo donde se oiga la cancion.' + hint);
    }

    const title = result.title || 'Desconocida';
    const artist = result.artist || result.artist_name || '';
    const album = result.album || '';
    const release = result.release_date || '';
    const score = result.timecode || '';
    const apple = result.apple_music?.url || '';
    const spotify = result.spotify?.external_urls?.spotify || result.spotify?.url || '';

    const lines = [
      '🎵 *SHAZAM*',
      '',
      '📌 *' + title + '*',
      artist ? '🎤 ' + artist : '',
      album ? '💿 ' + album : '',
      release ? '📅 ' + release : '',
      score ? '⏱️ ' + score : '',
      spotify ? '🟢 Spotify: ' + spotify : '',
      apple ? '🍎 Apple: ' + apple : '',
    ].filter(Boolean).join('\n');

    await c.reply(lines);
    await c.react('⏳');

    const audio = await fetchTrackAudio(title, artist);
    if (audio && audio.buf) {
      await c.sock.sendMessage(c.from, {
        audio: audio.buf,
        mimetype: 'audio/mpeg',
        fileName: (title + '.mp3').replace(/[^\w\s\.-]/g, ''),
        ptt: false,
      }, { quoted: c.m }).catch(async () => {
        await c.sock.sendMessage(c.from, {
          document: audio.buf,
          mimetype: 'audio/mpeg',
          fileName: 'song.mp3',
          caption: title + (artist ? ' — ' + artist : ''),
        }, { quoted: c.m });
      });
      await c.react('✅');
    } else {
      await c.reply('Reconocí la canción, pero no pude descargar el audio completo. Busca: *' + title + '* ' + artist);
      await c.react('✅');
    }
  }, ['queescancion', 'reconocermusica', 'whatmusic', 'songfind']),
];
